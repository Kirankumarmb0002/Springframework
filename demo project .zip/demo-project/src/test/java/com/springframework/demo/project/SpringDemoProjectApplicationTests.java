package com.springframework.demo.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
